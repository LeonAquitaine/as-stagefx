# AS StageFX Package
Version: 1.6.5

## Description
Complete collection of background effects (Requires Essentials)

## Installation
1. Copy the entire contents of this package to your ReShade installation directory
   (This is usually your game directory that contains the ReShade DLL)
2. The shaders will appear in the ReShade effects list under their respective categories

## Support
For help and updates, visit: https://github.com/YOUR-USERNAME/as-stagefx

